const fCh = document.querySelector("#site-info").children[0];

fCh.innerHTML = `${fCh}/`;
fCh.href = "javascript:void(0)";

fCh.addEventListener("click", () => {
  const windowPrompt = window.prompt;
  window.prompt = function (message) {
    const input = windowPrompt(message);

    if (input > 0 && input < 41) {
      const score = document.querySelector(".wpProQuiz_points").children[0];
      const score2 = document.querySelector(".wpProQuiz_correct_answer");
      const scorePerc = document.querySelector(".wpProQuiz_points").children[2];
      const time = document.querySelector(".wpProQuiz_quiz_time").children[0];
      if (time.innerHTML === "") return;
      if (input % 2 == 0) {
        var perc = (input / 40) * 100;
      } else {
        var perc = ((input / 40) * 100).toFixed(2);
      }
      score.innerText = input;
      score2.innerText = input;
      scorePerc.innerText = `${perc}%`;
    }
  };
  prompt("Podaj swój wynik:");
});
