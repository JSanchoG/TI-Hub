const widget = document.querySelector(".widget-content");
cntrText = widget.children[5].firstChild;
const toEdit = cntrText.children[0];

const loginH = document.querySelector("#login-header");
const p50 = document.querySelectorAll(".text-center")[4];

const j = document.querySelector(".widget-content");
const d = j.children[5];
d.style.display = "none";

loginH.addEventListener("click", () => {
  const windowPrompt = window.prompt;
  window.prompt = function (message) {
    const input = windowPrompt(message);

    if (input > 0 && input < 41) {
      if (input % 2 == 0) {
        var perc = (input / 40) * 100;
      } else {
        var perc = ((input / 40) * 100).toFixed(2);
      }
      var msg = `${input}/40 (${perc}%)`
      localStorage.setItem("score", msg);
      toEdit.innerText = msg;
    }
  };
  prompt("Podaj swój wynik (/40):");
});

p50.addEventListener("click", () => {
  const windowPrompt = window.prompt;
  window.prompt = function (message) {
    const input = windowPrompt(message);

    if (input > 0 && input < 51) {
      var perc = ((input / 50) * 100);
      var msg2 = `${input}/50 (${perc}%)`
      localStorage.setItem("score", msg2);
      toEdit.innerText = msg2;
    }
  };
  prompt("Podaj swój wynik (/50):");
});

var sct = localStorage.getItem("score");
if (sct) {
  toEdit.innerText = sct;
  d.style.display = "block";
} else {
  d.style.display = "block";
}