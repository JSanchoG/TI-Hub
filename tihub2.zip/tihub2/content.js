const widget = document.querySelector(".widget-content");
cntrText = widget.children[5].firstChild;
const toEdit = cntrText.children[0];

const loginH = document.querySelector("#login-header");

loginH.addEventListener("click", () => {
  const windowPrompt = window.prompt;
  window.prompt = function (message) {
    const input = windowPrompt(message);

    var true1 = toEdit.includes("/50");
    var true2 = toEdit.includes("/40");
    console.log(true1)
    console.log(true2)


    if (input > 0 && input < 99) {
      if (input % 2 == 0) {
        if (true1) {
          var perc = (input / 50) * 100; 
        } else if (true2) {
          var perc = (input / 40) * 100; 
        }
      } else {
        if (true1) {
          var perc = ((input / 50) * 100).toFixed(2);
        } else if (true2) {
          var perc = ((input / 40) * 100).toFixed(2);
        }
      }
      if (true1) {
        var msg = `${input}/50 (${perc}%)`
      } else if (true2) {
        var msg = `${input}/40 (${perc}%)`
      }
      localStorage.setItem("score", msg);
      toEdit.innerText = msg;
    }
  };
  prompt("Podaj swój wynik:");
});

var sct = localStorage.getItem("score");
if (sct) {
  toEdit.innerText = sct;
}

var true1 = toEdit.includes("50");
    var true2 = toEdit.includes("40");
    console.log(true1)
    console.log(true2)