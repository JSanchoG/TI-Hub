const widget = document.querySelector(".widget-content");
cntrText = widget.children[5].firstChild;
const toEdit = cntrText.children[0];

const loginH = document.querySelector("#login-header");

loginH.addEventListener("click", () => {
  const windowPrompt = window.prompt;
  window.prompt = function (message) {
    const input = windowPrompt(message);

    if (input > 0 && input < 41) {
      if (input % 2 == 0) {
        var perc = (input / 40) * 100;
      } else {
        var perc = ((input / 40) * 100).toFixed(2);
      }
      var msg = `${input}/40 (${perc}%)`
      localStorage.setItem("score", msg);
      toEdit.innerText = msg;
    }
  };
  prompt("Podaj swój wynik:");
});

var sct = localStorage.getItem("score");
if (sct) {
  toEdit.innerText = sct;
}